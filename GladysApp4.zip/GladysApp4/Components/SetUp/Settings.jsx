import { View, Text, StyleSheet, SafeAreaView, TouchableOpacity, Image, Switch } from 'react-native';
import React, { useState } from 'react';
import { useNavigation } from '@react-navigation/native';

export default function Settings() {
  const navigation = useNavigation();

  const [isDarkTheme, setIsDarkTheme] = useState(false);

  const toggleTheme = () => {
    setIsDarkTheme(previousState => !previousState);
  };

  const menuItems = [
    { label: 'Language', screen: 'Language' },
    { label: 'My Profile', screen: 'Profile' },
    { label: 'Contact Us', screen: 'ContactUs' },
    { label: 'Change Password', screen: 'ChangePassword' },
    { label: 'Privacy Policy', screen: 'PrivacyPolicy' },
  ];

  const currentStyles = isDarkTheme ? darkStyles : styles;

  return (
    <SafeAreaView style={currentStyles.container}>
      <View style={currentStyles.menu}>
        {menuItems.map((item, index) => (
          <TouchableOpacity
            key={index}
            style={currentStyles.menuItem}
            onPress={() => navigation.navigate(item.screen)}
          >
            <View style={currentStyles.menuItemContent}>
              <Text style={currentStyles.menuItemText}>{item.label}</Text>
              <Text style={currentStyles.menuItemArrow}>{'>'}</Text>
            </View>
          </TouchableOpacity>
        ))}
        <View style={currentStyles.themeToggle}>
          <Text style={currentStyles.menuItemText}>Theme</Text>
          <Switch
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={isDarkTheme ? '#f5dd4b' : '#f4f3f4'}
            onValueChange={toggleTheme}
            value={isDarkTheme}
          />
        </View>
      </View>

      <View style={currentStyles.bottomTab}>
        <TouchableOpacity style={currentStyles.tabItemBottom} onPress={() => navigation.navigate('Home')}>
          <Image source={'./assets/home.png'} style={currentStyles.tabIcon} />
          <Text style={currentStyles.tabText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={currentStyles.tabItemBottom}>
          <Image source={'./assets/myCards.png'} style={currentStyles.tabIcon} />
          <Text style={currentStyles.tabText}>My Cards</Text>
        </TouchableOpacity>
        <TouchableOpacity style={currentStyles.tabItemBottom}>
          <Image source={'./assets/statistics.png'} style={currentStyles.tabIcon} />
          <Text style={currentStyles.tabText}>Statistics</Text>
        </TouchableOpacity>
        <TouchableOpacity style={currentStyles.tabItemBottom}>
          <Image source={'./assets/settings.png'} style={currentStyles.tabIcon} />
          <Text style={currentStyles.tabText}>Settings</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin:20,
    marginTop:50,
    marginEnd:290,
   
  },

  menu: {
    flex: 1,
  },

  menuItem: {
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderColor: '#ddd',
  },

  menuItemText: {
    fontSize: 22,
    textAlign: 'left',
    color: '#000',
  },

  menuItemContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  themeToggle: {
    marginTop:50,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    paddingHorizontal: 10,
  },

  bottomTab: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 60,
    backgroundColor: '#E0E0E0',
    borderTopWidth: 1,
    borderColor: '#ddd',
  },

  tabItemBottom: {
    alignItems: 'center',
  },

  tabIcon: {
    height: 20,
    width: 20,
  },

  tabText: {
    marginTop: 5,
    color: '#000',
  },
});

const darkStyles = StyleSheet.create({
  container: {
    flex: 1,
    margin: 15,
    marginTop: 50,
    marginEnd: 270,
    backgroundColor: '#000000',
  },

  menu: {
    flex: 1,
  },

  menuItem: {
    paddingVertical: 15,
    paddingHorizontal: 10,
    borderBottomWidth: 1,
    borderColor: '#444',
  },

  menuItemText: {
    fontSize: 22,
    textAlign: 'left',
    color: '#FFF',
  },

  menuItemContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  menuItemArrow:{
    color:"#ffff"
  },

  themeToggle: {
    marginTop: 50,

    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    paddingHorizontal: 10,
  },

  bottomTab: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 60,
    backgroundColor: '#333',
    borderTopWidth: 1,
    borderColor: '#444',
  },

  tabItemBottom: {
    alignItems: 'center',
  },

  tabIcon: {
    height: 20,
    width: 20,
  },

  tabText: {
    marginTop: 5,
    color: '#FFF',
  },
});
