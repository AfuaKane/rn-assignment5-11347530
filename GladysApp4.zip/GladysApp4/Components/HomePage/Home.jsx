import { View, Text, SafeAreaView, Image, StyleSheet, FlatList, TouchableOpacity } from 'react-native'
import React from 'react'

export default function Home({navigation}) {
  // Sample data for the FlatList
  const data = [
    { id: '1', image: './assets/apple.png', title: 'Apple Store', subtitle: 'Entertainment', price: '-$5,99' },
    { id: '2', image: './assets/spotify.png', title: 'Spotify', subtitle: 'Music', price: '-$12,99' },
    { id: '3', image: './assets/moneyTransfer.png', title: 'Money Transfer', subtitle: 'Transaction ', price: '-$300' },
    { id: '4', image: './assets/grocery.png', title: 'Grocery',  price: '-$88' },
  ];

  return (
    <SafeAreaView style={styles.SafeArea}>
      <View style={styles.row}>
        <Image source={'./assets/profile.png'} style={styles.image} />

        <View style={styles.textContainer}>
          <Text style={styles.firstText}>Welcome back,</Text> 
          <Text style={styles.secondText}>Eric Atsu</Text>
        </View>   

        <Image source={'./assets/Search.png'} style={styles.searchIcon} />
      </View>

      <Image source={'./assets/card.png'} style={styles.masterCard} />

      <View style={styles.tabs}>
        <View style={styles.tabItem}>
          <Image source={'./assets/send (1).png'} style={styles.tabImage} />
          <Text style={styles.tabText}>Sent</Text>
        </View>
        <View style={styles.tabItem}>
          <Image source={'./assets/recieve.png'} style={styles.tabImage} />
          <Text style={styles.tabText}>Received</Text>
        </View>
        <View style={styles.tabItem}>
          <Image source={'./assets/loan.png'} style={styles.tabImage} />
          <Text style={styles.tabText}>Loan</Text>
        </View>
        <View style={styles.tabItem}>
          <Image source={'./assets/topUp.png'} style={styles.tabImage} />
          <Text style={styles.tabText}>Top Up</Text>
        </View>
      </View>

      <View style={styles.transactionRow}>
        <Text style={styles.transaction}>Transaction</Text>
        <TouchableOpacity>
          <Text style={styles.seeAll}>See All</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={data}
        renderItem={({ item }) => (
          <View style={styles.listItem}>
            <View style={styles.listContent}>
              <Image source={item.image} style={styles.listImage} />
              <View style={styles.listTextContainer}>
                <Text style={styles.listTitle}>{item.title}</Text>
                <Text style={styles.listSubtitle}>{item.subtitle}</Text>
              </View>
            </View>
            <Text style={styles.listPrice}>{item.price}</Text>
          </View>
        )}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContainer}
      />

<View style={styles.bottomTab}>
        <TouchableOpacity style={styles.tabItemBottom} >
          <Image source={"./assets/home.png"} style={styles.tabIcon} />
          <Text style={styles.tabText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tabItemBottom}>
          <Image source={"./assets/myCards.png"} style={styles.tabIcon} />
          <Text style={styles.tabText}>My Cards</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tabItemBottom}>
          <Image source={"./assets/statistics.png"} style={styles.tabIcon} />
          <Text style={styles.tabText}>Statistics</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tabItemBottom} 
        onPress={() => navigation.navigate('Settings')}>
          <Image source={"./assets/settings.png"} style={styles.tabIcon} />
          <Text style={styles.tabText}>Settings</Text>
        </TouchableOpacity>
      </View>    


    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  SafeArea: {
    flex: 1,
    margin:20,
    marginTop:50,
    marginEnd:270
   
  },

  row: {
    flexDirection: "row",
    alignItems: "center"
  },

  image: {
    height: 50,
    width: 50,
  },

  textContainer: {
    flexDirection: "column",
    marginLeft: 15
  },

  firstText: {
    fontSize: 15,
  },

  secondText: {
    fontSize: 20,
    fontWeight: "bold"
  },

  searchIcon: {
    marginLeft: 'auto',
    height: 30,
    width: 30,
    padding: 10,
    borderRadius: 25
  },

  masterCard: {
    height: 230,
    width: 380,
    marginTop: 25,
    alignItems: "center",
    borderRadius: 30,
    marginBottom: 25
  },

  tabs: {
   
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
  },

  tabItem: {
    alignItems: "center",
  },

  tabImage: {
    height: 20,
    width: 20,
   
  },

  tabText: {
    marginTop: 10,
  },

  transactionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 55,
  },

  transaction: {
    fontSize: 20,
    fontWeight: "bold",
  },

  seeAll: {
    fontSize: 20,
    color: 'blue',
    fontWeight: "bold",
  },

  listContainer: {
    marginTop: 5,
  },

  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 5,
  },

  listContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  listImage: {
    height: 25,
    width: 25,
    
  
  },

  listTextContainer: {
    flexDirection: 'column',
    margin:20,
  },

  listTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    

  },

  listSubtitle: {
    fontSize: 16,
    color: 'gray',
    
    marginTop:0.5
  },

  listPrice: {
    fontSize: 16,
    fontWeight: 'bold',
  },

  bottomTab: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    height: 60,
    backgroundColor: "#E0E0E0", // Color of the rectangular tab
    borderTopWidth: 1,
    borderColor: "#ddd",
  },

  tabItemBottom: {
    alignItems: "center",
  },

  tabIcon: {
    height: 20,
    width: 20,
  },
})
